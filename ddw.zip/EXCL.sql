delete from sas_pulse_stg.comm_nps_sb_trans_excl all;

insert into sas_pulse_stg.comm_nps_sb_trans_excl
select
cntct.email_addr_id,
max(ce.excl_src)
from sas_pulse_stg.comm_nps_sb_trans_final cntct 
inner join sas_pulse_stg.comm_nps_cntct_excl ce 
on cntct.email_addr_id = ce.email_addr_id
where ce.excl_src in ('SMX Opt Out')
/*where ce.excl_src in ('SMX Opt Out', 'Prev 1Q Response', 'Prev 4Q Bounce', 'Prev 1Q Invitation')*/
and cntct.email_addr_id not in (select email_addr_id from sas_pulse_stg.comm_nps_sb_trans_excl)
group by 1;


insert into sas_pulse_stg.comm_nps_sb_trans_excl
select
cntct.email_addr_id,
'GEMS Opt Out' as excl_src
from sas_pulse_stg.comm_nps_sb_trans_final cntct
inner join marcom.email_subscriber es 
on cntct.email_addr_id = trim(es.email_address)
where es.emailable_flag = 'N'
and cntct.email_addr_id not in (select email_addr_id from sas_pulse_stg.comm_nps_sb_trans_excl)
group by 1,2;


insert into sas_pulse_stg.comm_nps_sb_trans_excl
select
cntct.email_addr_id,
'Pulse Opt Out' as excl_src
from sas_pulse_stg.comm_nps_sb_trans_final cntct
inner join ce_base.survey_do_not_dstrb_list dnd 
on cntct.email_addr_id = dnd.email_addr_id
where dnd.email_type_flg = 'E' 
and cntct.email_addr_id not in (select email_addr_id from sas_pulse_stg.comm_nps_sb_trans_excl)
group by 1,2;


insert into sas_pulse_stg.comm_nps_sb_trans_excl
select
cntct.email_addr_id,
'Pulse Opt Out' as excl_src
from sas_pulse_stg.comm_nps_sb_trans_final cntct
inner join ce_base.survey_do_not_dstrb_list dnd 
on cntct.domain_email_addr_id = dnd.email_addr_id
where dnd.email_type_flg = 'D' 
and cntct.email_addr_id not in (select email_addr_id from sas_pulse_stg.comm_nps_sb_trans_excl)
group by 1,2;



insert into sas_pulse_stg.comm_nps_sb_trans_excl
select
cntct.email_addr_id,
'FY14Q4 CON/REU' as excl_src
from sas_pulse_stg.comm_nps_sb_trans_final cntct
where EMAIL_ADDR_ID IN(SELECT email_addr_id FROM  sas_pulse_stg.survey_invite WHERE wave_desc = 'FY15Q1')
and cntct.email_addr_id not in (select email_addr_id from sas_pulse_stg.comm_nps_sb_trans_excl)
group by 1,2;


insert into sas_pulse_stg.comm_nps_sb_trans_excl
select
cntct.email_addr_id,
'Commercial SFDC' as excl_src
from sas_pulse_stg.comm_nps_sb_trans_final cntct
where  EMAIL_ADDR_ID IN( SELECT email_addr_id FROM sas_pulse_stg.comm_nps_acct_seltn_4 )
and cntct.email_addr_id not in (select email_addr_id from sas_pulse_stg.comm_nps_sb_trans_excl)
group by 1,2;


insert into sas_pulse_stg.comm_nps_sb_trans_excl
select
cntct.email_addr_id,
'OEM' as excl_src
from sas_pulse_stg.comm_nps_sb_trans_final cntct
where  EMAIL_ADDR_ID IN (select email_addr_id from  sas_pulse_stg.comm_nps_oem_cntct )
and email_addr_id not in (select email_addr_id from  sas_pulse_stg.comm_nps_sb_trans_excl)
group by 1,2;


INSERT INTO sas_pulse_stg.comm_nps_sb_trans_excl
SELECT
cntct.email_addr_id,
'Channel' AS excl_src
FROM sas_pulse_stg.comm_nps_sb_trans_final cntct
WHERE EMAIL_ADDR_ID IN
	(SELECT smx.email_addr_id 
FROM sas_pulse_stg.comm_nps_cp_final smx
WHERE smx.email_addr_id NOT IN (SELECT email_addr_id FROM sas_pulse_stg.comm_nps_sb_trans_excl)
GROUP BY 1);



collect stats on sas_pulse_stg.comm_nps_sb_trans_excl;
